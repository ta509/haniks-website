// main.js - ملف JavaScript الرئيسي لموقع Haniks

document.addEventListener('DOMContentLoaded', function() {
    // تفعيل القائمة المتجاوبة للهواتف المحمولة
    const mobileMenuInit = () => {
        const header = document.querySelector('header');
        const menuToggle = document.createElement('div');
        menuToggle.className = 'menu-toggle';
        menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
        
        // إضافة زر القائمة فقط في حالة الشاشات الصغيرة
        if (window.innerWidth <= 768) {
            if (!document.querySelector('.menu-toggle')) {
                header.querySelector('.container').prepend(menuToggle);
                
                // إخفاء القائمة والزر CTA افتراضياً
                const nav = header.querySelector('nav');
                const ctaButton = header.querySelector('.cta-button');
                nav.style.display = 'none';
                if (ctaButton) ctaButton.style.display = 'none';
                
                // تفعيل زر القائمة
                menuToggle.addEventListener('click', function() {
                    if (nav.style.display === 'none') {
                        nav.style.display = 'block';
                        if (ctaButton) ctaButton.style.display = 'block';
                        menuToggle.innerHTML = '<i class="fas fa-times"></i>';
                    } else {
                        nav.style.display = 'none';
                        if (ctaButton) ctaButton.style.display = 'none';
                        menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
                    }
                });
            }
        } else {
            // إزالة زر القائمة وإظهار القائمة في الشاشات الكبيرة
            const existingToggle = document.querySelector('.menu-toggle');
            if (existingToggle) existingToggle.remove();
            
            const nav = header.querySelector('nav');
            const ctaButton = header.querySelector('.cta-button');
            nav.style.display = 'block';
            if (ctaButton) ctaButton.style.display = 'block';
        }
    };

    // تفعيل القائمة المتجاوبة عند تحميل الصفحة وتغيير حجم النافذة
    mobileMenuInit();
    window.addEventListener('resize', mobileMenuInit);

    // تأثيرات التمرير السلس للروابط الداخلية
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });

    // تفعيل تأثيرات التمرير للعناصر
    const animateOnScroll = () => {
        const elements = document.querySelectorAll('.feature, .feature-card, .gallery-item, .specs-group');
        
        elements.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const screenPosition = window.innerHeight / 1.3;
            
            if (elementPosition < screenPosition) {
                element.classList.add('animate');
            }
        });
    };

    // إضافة فئة CSS للتحريك
    const addAnimationClass = () => {
        const style = document.createElement('style');
        style.textContent = `
            .feature, .feature-card, .gallery-item, .specs-group {
                opacity: 0;
                transform: translateY(20px);
                transition: opacity 0.5s ease, transform 0.5s ease;
            }
            .feature.animate, .feature-card.animate, .gallery-item.animate, .specs-group.animate {
                opacity: 1;
                transform: translateY(0);
            }
        `;
        document.head.appendChild(style);
    };

    addAnimationClass();
    window.addEventListener('scroll', animateOnScroll);
    // تشغيل التحريك مرة واحدة عند تحميل الصفحة
    setTimeout(animateOnScroll, 500);

    // التحقق من صحة نموذج التواصل
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // التحقق من الحقول المطلوبة
            let isValid = true;
            const name = document.getElementById('name');
            const email = document.getElementById('email');
            const message = document.getElementById('message');
            
            // إزالة رسائل الخطأ السابقة
            document.querySelectorAll('.error-message').forEach(el => el.remove());
            
            // التحقق من الاسم
            if (!name.value.trim()) {
                showError(name, 'الرجاء إدخال الاسم');
                isValid = false;
            }
            
            // التحقق من البريد الإلكتروني
            if (!email.value.trim()) {
                showError(email, 'الرجاء إدخال البريد الإلكتروني');
                isValid = false;
            } else if (!isValidEmail(email.value)) {
                showError(email, 'الرجاء إدخال بريد إلكتروني صحيح');
                isValid = false;
            }
            
            // التحقق من الرسالة
            if (!message.value.trim()) {
                showError(message, 'الرجاء إدخال رسالتك');
                isValid = false;
            }
            
            // إرسال النموذج إذا كان صحيحاً
            if (isValid) {
                // هنا يمكن إضافة كود لإرسال النموذج إلى الخادم
                // في هذا المثال، سنعرض رسالة نجاح فقط
                
                const successMessage = document.createElement('div');
                successMessage.className = 'success-message';
                successMessage.textContent = 'تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.';
                successMessage.style.cssText = 'background-color: #4CAF50; color: white; padding: 15px; border-radius: 5px; margin-top: 20px;';
                
                contactForm.appendChild(successMessage);
                contactForm.reset();
                
                // إخفاء رسالة النجاح بعد 5 ثوانٍ
                setTimeout(() => {
                    successMessage.style.opacity = '0';
                    successMessage.style.transition = 'opacity 0.5s ease';
                    setTimeout(() => successMessage.remove(), 500);
                }, 5000);
            }
        });
    }

    // دالة لعرض رسائل الخطأ
    function showError(inputElement, message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        errorDiv.style.cssText = 'color: #e74c3c; font-size: 0.9rem; margin-top: 5px;';
        
        inputElement.style.borderColor = '#e74c3c';
        inputElement.parentNode.appendChild(errorDiv);
        
        // إزالة تنسيق الخطأ عند الكتابة
        inputElement.addEventListener('input', function() {
            this.style.borderColor = '';
            const error = this.parentNode.querySelector('.error-message');
            if (error) error.remove();
        });
    }

    // دالة للتحقق من صحة البريد الإلكتروني
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // تفعيل تأثيرات الصور في معرض الصور
    const galleryItems = document.querySelectorAll('.gallery-item');
    galleryItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.querySelector('.overlay').style.transform = 'translateY(0)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.querySelector('.overlay').style.transform = 'translateY(100%)';
        });
    });

    // تفعيل الأسئلة الشائعة في صفحة التواصل
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('h3');
        const answer = item.querySelector('p');
        
        // إضافة أيقونة السهم
        const icon = document.createElement('i');
        icon.className = 'fas fa-chevron-down';
        icon.style.cssText = 'margin-right: 10px; transition: transform 0.3s ease;';
        question.prepend(icon);
        
        // إخفاء الإجابات افتراضياً
        answer.style.display = 'none';
        
        question.addEventListener('click', function() {
            // تبديل عرض الإجابة
            if (answer.style.display === 'none') {
                answer.style.display = 'block';
                icon.style.transform = 'rotate(180deg)';
            } else {
                answer.style.display = 'none';
                icon.style.transform = 'rotate(0)';
            }
        });
    });
});
